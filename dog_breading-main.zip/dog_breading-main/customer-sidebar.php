<div class="admin_panel">
            <ul>
                <li><a href="user-account.php">My Account</a></li>
                <li><a href="index.php">Buy Dog</a></li>
                <li><a href="cart.php">Checkout</a></li>
                <li><a href="order-history.php">Order History</a></li>
                <li><a href="logout.php">Logout</a></li>
                
            </ul>
        </div>