<?php
include('header.php');
?>


  <div id="main-content" >

    <div class="content-left">
        <!-- side bar here -->
        <?php include('b_side_bar.php');?>
        <!-- side bar end -->

    </div>

<div class="right">
    
  </div>
</div>

<?php include('footer.php');
?>