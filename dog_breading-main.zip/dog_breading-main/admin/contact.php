<?php
// session_start();
// top menu ///
error_reporting(0);

include('header.php');
?>



  <div id="main-content" >

    <!-- <div class="content-left">
       
    </div> -->

<div class="right" style="height:auto;width:100%;">

<div class="about" style="padding:20px;width:900px;">
            <h4>Our Contact Info</h4>
            <table cellpadding:5px;>
                <tr>
                    <td style="font-weight:bold;">Our Location:</td><td>No K/S6/7 alerio sokoto raod, jega, kebbi State</td>
                </tr>

                <tr>
                    <td style="font-weight:bold;">Email:</td><td> blb@gmail.com</td>
                </tr>
                <tr>
                    <td style="font-weight:bold;">Phone:</td><td>+2348101234567</td>
                </tr>

            </table>

        </div>
        
  </div>
</div>

<?php include('footer.php');
?>