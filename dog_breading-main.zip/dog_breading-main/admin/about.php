<?php
error_reporting(0);
// session_start();

include('header.php');


?>



  <div id="main-content" >

    <!-- <div class="content-left">
       
    </div> -->

<div class="right" style="height:auto;width:100%;">
<div class="about" style="padding:50px; width:900px;">
            <h4>About Us</h4>
            <p style="width:80%;">
               Lorem ipsum dolor sit amet consectetur adipisicing elit. Hic animi commodi necessitatibus at. Fuga iure minima dolor alias, debitis quis, natus ex quibusdam molestias illo omnis inventore voluptatibus. Cumque vero totam fugit unde quasi non! Quae, vero tempora exercitationem, cumque voluptate placeat corporis perspiciatis provident, autem velit tenetur cum impedit!
            </p>

        </div>
  </div>
</div>

<?php include('footer.php');
?>