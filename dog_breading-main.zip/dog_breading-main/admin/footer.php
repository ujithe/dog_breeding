<div class="footer">
  <div class="foot-container">
  <div class="footer-left">
    <h2>DOGS WORLD</h2>
    <P style="margin-left:10px;text-align:justify">DOGS WORLD was established in 2020 at No where, along St road and now it has several branches and extensions, such. </P>
    
  </div>
  <div class="footer-middle" style="text-align:center">
    <h2>OPENING TIME</h2>
    <ul style="margin-left:20%;">
      <li>Monday-Friday: ------ 8:00am to 10:00pm</li>
      <li>Satuday:      ------- 9:00am to 10:00pm</li>
      <li>Sunday: -------- 10:00am to 10:00pm</li>
    </ul>
  </div>
  <div class="footer-right">
    <h2>Contact-INFORMATION</h2>
    <ul style="margin-left:20%;">
      <li>Location: No 6 alakija lagos </li>
      <li>Phone:  +234812211234567</li>
      <li>email:  dw@gmail.com</li>
    </ul>

   
  </div>
</div>
<hr>
  &copy copy right 2023  dogs   world:.
  </div>
</div>
</body>
</html>