<?php

error_reporting(0);


// top menu end//
include('header.php');

?>



  <div id="main-content" >

    <!-- <div class="content-left">
       
    </div> -->

<div class="right" style="height:auto;">
<div class="about" style="padding:50px; width:100%;">
            <h4>OUR SERVICES</h4>
            <p>
                We offer the best services....
            </p>

        </div>
  </div>
</div>

<?php include('footer.php');
?>