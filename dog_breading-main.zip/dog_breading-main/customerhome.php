<?php
session_start();
error_reporting(0);

include('menu-2.php');

include('header.php');
?>


  <div id="main-content" >

    <div class="content-left">
        <?php include('customer-sidebar.php');?>
    </div>
    
  </div>
</div>

<?php include('footer.php');
?>